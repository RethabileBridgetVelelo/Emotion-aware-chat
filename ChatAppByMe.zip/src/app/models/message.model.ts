export interface Message {
  senderId: string;
  text: string;
  timestamp: number;
  sentiment?: 'positive' | 'neutral' | 'negative';
}
