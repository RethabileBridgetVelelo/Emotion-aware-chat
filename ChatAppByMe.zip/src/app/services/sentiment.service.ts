import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SentimentService {

  analyze(text: string): 'positive' | 'neutral' | 'negative' {
    const positiveWords = ['love', 'grateful', 'happy', 'safe'];
    const negativeWords = ['empty', 'alone', 'tired', 'scared'];

    if (negativeWords.some(w => text.toLowerCase().includes(w))) {
      return 'negative';
    }
    if (positiveWords.some(w => text.toLowerCase().includes(w))) {
      return 'positive';
    }
    return 'neutral';
  }
}
