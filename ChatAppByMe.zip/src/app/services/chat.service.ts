import { Injectable } from '@angular/core';
import { Firestore, collection, addDoc, collectionData } from '@angular/fire/firestore';
import { Message } from '../models/message.model';

@Injectable({ providedIn: 'root' })
export class ChatService {
  constructor(private firestore: Firestore) {}

  sendMessage(message: Message) {
    const messagesRef = collection(this.firestore, 'messages');
    return addDoc(messagesRef, message);
  }

  getMessages() {
    const messagesRef = collection(this.firestore, 'messages');
    return collectionData(messagesRef, { idField: 'id' });
  }
}
